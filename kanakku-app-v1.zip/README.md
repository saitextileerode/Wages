# கணக்கு புத்தகம் (Android app) - version 1.0

ஊழியர் வருகை, வார / மாத / சண்டே கணக்கு, அட்வான்ஸ், படம் அனுப்புதல் எல்லாம் உள்ள Android app.
டேட்டா ஃபோனிலேயே சேமிக்கப்படும். app-ஐ update செய்தாலும் (அதே key-ல் sign ஆவதால்) பழைய டேட்டா அழியாது.

## GitHub-ல் APK உருவாக்கும் வழி
1. புதிய repository (Public) உருவாக்கவும்.
2. இந்த ZIP-ஐ (kanakku-app-v1.zip) repository-ல் அப்படியே upload செய்யவும் (விரிக்க வேண்டாம்).
3. `.github/workflows/build.yml` என்ற ஃபைலை உருவாக்கி, கொடுக்கப்பட்ட build.yml உள்ளடக்கத்தை ஒட்டவும்.
4. Actions tab > Build APK > முடிந்ததும் கீழே உள்ள Kanakku-APK-ஐ download செய்து, அதற்குள் இருக்கும் app-debug.apk-ஐ ஃபோனில் install செய்யவும்.

## Update செய்யும்போது
புதிய ZIP-ஐ kanakku-app-v2.zip என்ற பெயரில் upload செய்யவும் (எண் உயர்ந்திருக்க வேண்டும்). புதிய APK-ஐ பழையதன் மேலேயே install செய்யவும்.
